from django.urls import path
from wxapp.views import WXView, QrcodeView, QrCallbackView

urlpatterns = [
    path('', WXView.as_view()),
    path('qrcode', QrcodeView.as_view()),
    path('qrcallback/', QrCallbackView.as_view()),
]
