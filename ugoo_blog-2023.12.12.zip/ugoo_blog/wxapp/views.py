from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.views import View
from django.core.cache import cache
from django.contrib.auth.models import User

APPID = 'wx35c562da9ce9aaef'  # 公众号的唯一标识
APPSECRET = '8d4829703bafab2cff5ec9875124fecc'  # 公众号的appsecret
REDIRECT_URI = 'http://59.110.53.20/wx/qrcallback'  # 授权后重定向的回调链接地址， 请使用 urlEncode 对链接进行处理


# Create your views here.
# 接入微信公众平台开发
class WXView(View):
    def get(self, request):
        import hashlib
        token = 'ugoo'
        try:
            timestamp = request.GET['timestamp']  # 时间戳
            nonce = request.GET['nonce']  # 随机数
            data_list = [token, timestamp, nonce]  # 将三个参数放到一个列表中
            data_list.sort()  # 对三个参数进行排序
            data_str = ''.join(data_list)  # 将三个参数拼接成一个字符串
            # 对字符串进行sha1加密
            datasha1 = hashlib.sha1()
            datasha1.update(data_str.encode('utf-8'))
            hashcode = datasha1.hexdigest()
            signature = request.GET['signature']  # 微信加密签名
            if hashcode == signature:
                echostr = request.GET['echostr']  # 随机字符串
                return HttpResponse(echostr)
            else:
                return HttpResponse('The signature is faild!!!')
        except Exception:
            return HttpResponse('The wx get is faild!!!')


#   二维码生成
class QrcodeView(View):

    def get(self, request):
        import time
        import uuid
        timestamp = time.time_ns()  # 时间戳 ns
        state = '{0}-{1}'.format(uuid.uuid4(), str(timestamp))  # 重定向后会带上state参数，开发者可以填写a-zA-Z0-9的参数值，最多128字节
        cache.set(state, 'noscan', 300)  # 缓存 5min
        url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid={0}&redirect_uri={1}&response_type=code&scope=snsapi_base&state={2}#wechat_redirect'.format(
            APPID, REDIRECT_URI, state)  # 微信网页授权url
        return JsonResponse({'status': 200, 'url': url, 'state': state})


# 微信网页授权结果
class QrCallbackView(View):
    template_name = 'wxapp/result.html'

    def get(self, request):
        import requests
        try:
            code = request.GET['code']  # 换取access_token的票据
            state = request.GET['state']    #
            statecache = cache.get(state)   # 获取缓存状态
            # 二维码已失效
            if not statecache:
                return render(request, self.template_name, {'msg': '"该二维码已失效！"'})
            # 二维码未被扫描
            elif statecache == 'noscan':
                url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid={0}&secret={1}&code={2}&grant_type=authorization_code'.format(
                    APPID, APPSECRET, code) # 通过code换取网页授权access_token
                response = requests.get(url)
                if response.status_code == 200:
                    data = response.json()
                    openid = data['openid'] # 用户唯一标识
                    user = User.objects.filter(extension__openid=openid).first()    # 查询该用户是否绑定账号
                    if not user:
                        cache.set(state, 'nobind', 180)
                        msg = '"该微信用户未绑定账号！"'
                    else:
                        cache.set(state, user.username, 180)
                        msg = '"登录成功！"'
                else:
                    cache.set(state, 'scan', 180)
                    msg = '用户登录异常，请重新扫码登录！'
                return render(request, self.template_name, {'msg': msg})
            else:
                cache.set(state, 'scan', 180)
                return render(request, self.template_name, {'msg': '"该二维码已被扫描！"'})
        except Exception as e:
            print(e)
            return HttpResponse('the qrcode callback is faild!!!')
