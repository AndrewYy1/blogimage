from django.shortcuts import render
from django.views import View
from django.http import JsonResponse
from django.contrib import auth
import json
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.cache import cache
from django.contrib.auth.models import User


# 首页
class IndexViews(LoginRequiredMixin, View):
    login_url = "/web/login"

    def get(self, request):
        return JsonResponse({'status': 200, 'state': 'success'})


# Create your views here.
# 用户登录
class LoginView(View):
    template_name = 'webapp/login.html'

    def get(self, request):
        next_url = request.GET.get('next', '/web/index')
        return render(request, self.template_name, {'next_url': json.dumps(next_url)})

    def post(self, request):
        username = request.POST['username']  # 用户名
        password = request.POST['password']  # 密码
        nexturl = request.POST['nexturl']  # 用户访问页面
        user = auth.authenticate(username=username, password=password)  # 登录验证
        if user is not None:
            auth.login(request, user)  # 用户登录
            return JsonResponse({'status': 200, 'msg': nexturl})
        else:
            return JsonResponse({'status': 500, 'msg': '用户不存在或密码错误！'})


# 二维码扫描状态查询
class ScanQuery(View):
    def post(self, request):
        state = request.POST['state']  # 参数获取
        nexturl = request.POST['nexturl']  # 访问页面获取
        statecache = cache.get(state)  # 二维码状态获取
        # 二维码已失效
        if not statecache:
            return JsonResponse({'status': 200, 'state': 'timeout'})
        # 二维码未扫描
        elif statecache == 'noscan':
            return JsonResponse({'status': 200, 'state': 'noscan'})
        # 未绑定
        elif statecache == 'nobind':
            return JsonResponse({'status': 500, 'state': '该微信用户未绑定账号！'})
        # 登录
        else:
            user = User.objects.filter(username=statecache).first()
            auth.login(request, user)  # 用户登录
            return JsonResponse({'status': 200, 'state': 'login', 'url': nexturl})
