from django.urls import path
from webapp.views import LoginView, ScanQuery, IndexViews

urlpatterns = [
    path('', IndexViews.as_view()),
    path('login', LoginView.as_view()),
    path('index', IndexViews.as_view()),
    path('scanquery', ScanQuery.as_view()),
]
