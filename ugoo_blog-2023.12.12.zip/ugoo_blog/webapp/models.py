from django.db import models
from django.contrib.auth.models import User
from datetime import date
from django.db.models.signals import post_save
from django.dispatch import receiver


# Create your models here.
# 用户扩展
class UserExtension(models.Model):
    perm_choice = [
        (0, u'用户'),
        (1, u'维护员'),
        (2, u'经理'),
        (3, u'管理员'),
    ]
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='extension')
    openid = models.CharField(null=True, blank=True, unique=True, verbose_name='微信openid', max_length=50)
    realname = models.CharField(null=True, blank=True, verbose_name='真实姓名', max_length=50)
    position = models.CharField(null=True, blank=True, verbose_name='职位', max_length=100)
    entrytime = models.DateField(null=True, blank=True, verbose_name='入职时间', default=date.fromisoformat('1949-10-01'))
    telphone = models.CharField(null=True, blank=True, verbose_name='手机号码', max_length=15)
    perm = models.IntegerField(null=True, blank=True, verbose_name='权限等级', default=0, choices=perm_choice)

    class Meta:
        permissions = [
            ('maintainer', u'维护员'),
            ('manager', u'经理'),
            ('admin', u'管理员'),
        ]


@receiver(post_save, sender=User)
def create_user_extension(sender, instance, created, **kwargs):
    if created:
        UserExtension.objects.create(user=instance)
    else:
        instance.extension.save()
